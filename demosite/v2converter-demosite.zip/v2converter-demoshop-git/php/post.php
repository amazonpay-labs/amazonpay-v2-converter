<?php
function execute($requestJson) {
    error_log(print_r($requestJson,true),"3","./debug.log");

    $header = [
        'Content-Type: application/json',
        'x-api-key: XXX' //TODO AWS上に構築した API_KEY を設定
    ];

    $curl = curl_init();

    curl_setopt($curl, CURLOPT_URL, 'https://XXX.execute-api.ap-northeast-1.amazonaws.com/AmazonPay/'); //TODO AWS上に構築した API_ENDPOINT を設定
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST'); // post
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($requestJson));
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, true);
    
    $response = curl_exec($curl);
    
    $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE); 
    $header = substr($response, 0, $header_size);
    $body = substr($response, $header_size);
    $result = json_decode($body, true); 
    
    error_log(print_r($result,true),"3","./debug.log");

    curl_close($curl);

    return json_encode($result);
}