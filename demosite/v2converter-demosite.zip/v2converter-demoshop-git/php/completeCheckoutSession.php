<?php
require_once("post.php");

try {
    $checkoutSessionId = $_GET["amazonCheckoutSessionId"];
    $completeCheckoutSessionRequest = array(
        "action" => "CompleteCheckoutSession",
        "checkoutSessionId"=>$checkoutSessionId,
        "chargeAmount" => [
            "amount" => "1000",
            "currencyCode" => "JPY"
        ]
    );
    $completeCheckoutSessionResult = execute($completeCheckoutSessionRequest);
 
    $completeCheckoutSessionJsonResult = json_decode($completeCheckoutSessionResult);
    $authorizeState = $completeCheckoutSessionJsonResult->statusDetails->state;

    if ("Completed" == $authorizeState) {
        header("location: ../3.thanks.html");
        exit();
    }

    header("location: ../1.cart.html?error=payment-failure");
    exit();

} catch (\Exception $e) {
    // handle the exception
    header("location: ../1.cart.html?error=payment-failure");
}