
<?php
   require_once("post.php");

   $clientId = $_GET['clientId'];
   $request = [
      "action" => "CreateCheckoutSession",
      "webCheckoutDetails" => [
         "checkoutReviewReturnUrl"=> "http://localhost:8080/2.confirmation.html"
      ],
      "storeId" => $clientId
   ];

   $result = execute($request);
   echo $result;