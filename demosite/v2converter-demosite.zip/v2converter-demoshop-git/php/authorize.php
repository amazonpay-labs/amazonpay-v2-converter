<?php
require_once("post.php");

try {
    $checkoutSessionId = $_GET['amazonCheckoutSessionId'];
    $getCheckoutSessionRequest = array(
        'action'=>'GetCheckoutSession',
        'checkoutSessionId'=>$checkoutSessionId
    ); 
    $getCheckoutSessionResult = execute($getCheckoutSessionRequest);
 
    $getCheckoutSessionJsonResult = json_decode($getCheckoutSessionResult);

    $authorizeState = $getCheckoutSessionJsonResult->statusDetail->state;

    if ('Completed' == $authorizeState) {
        $captureChargeRequest = [
            "action" => "CaptureCharge",
            "chargeId" => $getCheckoutSessionJsonResult->chargeId,
            "captureAmount" => [
                "amount" => "1000",
                "currencyCode" => "JPY"
            ],
        ];

        // if you want to execute capture API
        $captureChargeResult = execute($captureChargeRequest);
        $captureChargeJsonResult = json_decode($captureChargeResult);

        $captureState = $captureChargeJsonResult->statusDetail->state;


        if('Captured' == $captureState) {
            header('location: ../3.thanks.html');
            exit();
        }
    }

    header('location: ../1.cart.html?error=payment-failure');
    exit();

} catch (\Exception $e) {
    // handle the exception
    header('location: ../1.cart.html?error=payment-failure');
}