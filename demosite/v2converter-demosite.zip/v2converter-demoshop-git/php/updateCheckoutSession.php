<?php
   require_once("post.php");

   $updateCheckoutSession = [
      "action" => "UpdateCheckoutSession",
      "checkoutSessionId" => $_POST['checkoutSessionId'],
      "webCheckoutDetails" => [
         "checkoutResultReturnUrl" => "http://localhost:8080/php/completeCheckoutSession.php"
      ],
      "paymentDetails" => [
         "paymentIntent" => "AuthorizeWithCapture", //TODO オーソリのみ:Authorize 即時売上請求：AuthorizeWithCapture
         "chargeAmount" => [
            "amount" => "1000",
            "currencyCode" => "JPY"
         ]
      ],
      "merchantMetadata" => [
         "merchantReferenceId" => "amazonpay-1234",
         "merchantStoreName" => "Merchant store name",
         "noteToBuyer" => "Note to buyer",
         "customInformation" => "Custom information"
      ]
   ];

   $updateCheckoutSessionResult = execute($updateCheckoutSession);

   $updateJson = json_decode($updateCheckoutSessionResult);

   try {
      header("Location: " . $updateJson->webCheckoutDetails->amazonPayRedirectUrl);

   } catch(Exception $e) {
      //TODO transition a error page.
      header("Location: ../1.cart.html?error=failure");
   }