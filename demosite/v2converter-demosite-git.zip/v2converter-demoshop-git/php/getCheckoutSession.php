<?php
   require_once("post.php");

   $requestJson = file_get_contents('php://input');
   $request = json_decode($requestJson);
   $request->action = 'GetCheckoutSession';

   $result = execute($request);
   echo $result;